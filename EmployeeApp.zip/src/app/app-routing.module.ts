import { EmployeeByDeptComponent } from './components/employee-by-dept/employee-by-dept.component';
import { EmployeeComponent } from './components/employee/employee.component';
import { DepartmentComponent } from './components/department/department.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


export const routes: Routes = [
  { path: '',  redirectTo: 'department', pathMatch: 'full' },
  { path: 'department', component: DepartmentComponent },
  { path: 'employee', component: EmployeeComponent},
  { path: 'employeeByDept/:deptCode', component: EmployeeByDeptComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
