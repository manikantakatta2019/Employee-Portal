import { CommonService } from './../../services/common.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-by-dept',
  templateUrl: './employee-by-dept.component.html',
  styleUrls: ['./employee-by-dept.component.css']
})
export class EmployeeByDeptComponent implements OnInit {
  empDataByDept = [];
  constructor(private route: ActivatedRoute, public commonService: CommonService) {
    this.route.params.subscribe(params => this.getEmployeeByDeptCode(params) );
  }

  ngOnInit(): void {
  }
  getEmployeeByDeptCode(params) {

    this.commonService.getAllEmployee().subscribe(res => {
      res.empData.forEach(emp => {
        if (emp.deptCode === params.deptCode) {
          this.empDataByDept.push(emp);
        }
      });
    });

  }
}
