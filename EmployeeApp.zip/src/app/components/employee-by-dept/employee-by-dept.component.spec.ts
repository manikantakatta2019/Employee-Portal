import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeByDeptComponent } from './employee-by-dept.component';

describe('EmployeeByDeptComponent', () => {
  let component: EmployeeByDeptComponent;
  let fixture: ComponentFixture<EmployeeByDeptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeByDeptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeByDeptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
