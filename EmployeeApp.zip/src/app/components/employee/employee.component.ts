import { CommonService } from './../../services/common.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  allEmployeeData: any;
 constructor(public commonService: CommonService) {
  }

  ngOnInit(): void {
    this.getAllEmpolyee();
  }

  getAllEmpolyee() {
    this.commonService.getAllEmployee().subscribe(res => {
      this.allEmployeeData = res.empData;
    });
  }
}
