import { Router } from '@angular/router';
import { CommonService } from './../../services/common.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {
  departmentData: any;
  employeeData: any;
  constructor(public commonService: CommonService,public router: Router) { }

  ngOnInit(): void {
    this.getAllEmpolyee();
    this.getAllDepartments();
  }
  getAllEmpolyee() {
    this.commonService.getAllEmployee().subscribe(res => {
      this.employeeData = res.empData;
      //console.log(this.employeeData);
    });
  }
  getAllDepartments() {
    this.commonService.getAllDepartments().subscribe(res => {
      this.departmentData = res.deptData;
      this.departmentData.forEach((dept, i) => {
        for (const emp in this.employeeData) {
          if (this.employeeData.hasOwnProperty(emp)) {
            if (this.departmentData[i].deptCode === this.employeeData[emp].deptCode) {
              this.departmentData[i].empCount += 1;
            }
          }
        }
      });

      console.log(this.departmentData);
    });
  }

  showEmp(dept){
    this.router.navigate(['employeeByDept/', dept.deptCode]);

  }
}